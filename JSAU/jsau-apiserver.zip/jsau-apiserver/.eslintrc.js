module.exports = {
    extends: 'usecases/usecase/nodejs'
}
