module.exports = {
    extends: 'usecases/usecase/nodejs',
    rules: {
        'no-console': 'off',
    }
}
