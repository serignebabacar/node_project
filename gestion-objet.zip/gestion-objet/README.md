#installation projet : npm ci ou npm install


#pour importer la base de donnée : https://docs.mongodb.com/manual/reference/program/mongoimport/
